import parse
import subprocess

# return True on segfault
def send(words: dict) -> bool:
    print("\n\n\n\n=============================================")
    # print(words)
    # print("\n\n\n\n=============================================")
    input = parse.getInputFromDict(words)

    print(input)
    p = subprocess.Popen(binary, stdin=PIPE)
    outs, errs = p.communicate(input.encode())
    print(outs)
    print(errs)

    if p.returncode != 0: # 139 for segfault
        print(p.returncode)
        return input

    return None