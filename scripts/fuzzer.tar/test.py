import random
cases = [(i, j) for i in range(500) for j in range(0x100)]
random.shuffle(cases)
print(cases)

cases = [random.sample([j for j in range(0x100)], 0x100) for i in range(500)]
